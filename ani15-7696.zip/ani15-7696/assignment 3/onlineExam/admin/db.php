<?php    


$host="localhost";
$user="root";
$pass="";
$db="exam";


$connection=mysqli_connect($host,$user,$pass,$db);


// if ($connection) {
// 	echo "connected";
// }else{
//     echo "not conected";
// }


