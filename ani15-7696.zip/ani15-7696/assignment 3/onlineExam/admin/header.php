
<?php session_start() ?>





<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="icon" href="img/5.png" type="image/gif">
	<meta charset="UTF-8">
	<title>Admin_Dashboad</title>

<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/5.11.2/css/font-awesome.min.css">


 <style type="text/css">
  *{
   margin: 0;
   padding: 0;
   font-family: sans-serif;
  }

  #sidebar{
   position: fixed;
   width: 200px;
   height: 100%;
   background: #151719;
   left: -200px;
   transition: all 500ms linear;
  }
  #sidebar.active{
   left:0px;
  }
  #sidebar ul li a{
   color: rgba(230,230,230,0.9);
   list-style: none;
   padding: 15px 10px;
   border-bottom: 1px solid rgba(100,100,100,0.3);
  }
 #sidebar ul li a:hover{

background-color: blue;


  }
  #sidebar .toggle-btn{
   position: absolute;
   left: 230px;
   top: 20px;
  }
  #sidebar .toggle-btn span{
   display: block;
   width: 30px;
   height: 5px;
   background: #151719;
   margin: 5px 0px;

  }
 </style>
 <script type="text/javascript">
  function toggleSidebar(){
   document.getElementById("sidebar").classList.toggle('active');
  }
 </script>
</head>








<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light" >
  <a class="navbar-brand" href="#" style="margin-left: 550px;">Online Examinaton</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto" style="margin-left: 350px;">
      <li class="nav-item active">
        <a class="nav-link" href="admin-dashboard.php">Home <span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Acoount
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          
          <a class="dropdown-item" href="change_pasword.php">Change Passwod</a>
          
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
      
    </ul>
    
  </div>
</nav>














 <div id="sidebar">
  <div class="toggle-btn" onclick="toggleSidebar()"><a>
   <span></span>
   <span></span>
   <span></span>
  </a>
  </div>
  <img src="img/1.png" alt="" style="width: 50px;height: 50px; margin-left: 50px;">
  
<p style="color: white; padding-left: 50px;"><b>Admin <img src="img/2.png" alt="" style="width: 10px;height: 10px; " >
</b></p>

  <ul>
    <li> <a href="subject.php" class="list-group-item list-group-item-action bg-dark">Subject</a></li>
    <li> <a href="teacher.php" class="list-group-item list-group-item-action bg-dark">teacher</a></li>
   <li> <a href="student.php" class="list-group-item list-group-item-action bg-dark">Student</a></li>
  </ul>
 </div>
