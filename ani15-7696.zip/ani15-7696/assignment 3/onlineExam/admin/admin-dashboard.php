<?php include('header.php') ?>



<?php
if(!isset($_SESSION['valid'])) {
  header('Location: admin-login.php');
}
?>






















<?php include('footer.php') ?>