	

<?php include('header.php') ?>
 
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: admin-login.php');
}
?>




<?php 


 $ename=$edesignation=$eemail=$epassword=$sucmsg="";

if (isset($_POST['submit'])) {
  




if(empty($_POST['name'])){
  $ename="Name field must be required !";
  $name="";
}else{
  $name=$_POST['name'];
}
if(empty($_POST['designation'])){
  $edesignation="Designation field must be required !";
  $designation="";
}else{
  $designation=$_POST['designation'];
}



if(empty($_POST['email'])){
  $eemail="email field must be required !";
  $email="";
}else{
  $email=$_POST['email'];
}























if(empty($_POST['password'])){
  $epassword="password field must be required !";
  $password="";
}else{
  $password=md5($_POST['password']);
}


if ($name !="" && $designation !=""  && $email !=""  && $password !="") {
 
 mysqli_query($connection,"INSERT INTO teacher(name,designation,email,password)VALUES('$name','$designation','$email','$password')");

 $sucmsg="Register Succesfully!";

}


  


}


 ?>


























<div class="card" style="width: 23rem; margin-left: 470px; " >
  <img class="card-img-top" src="img/re.jpg" alt="Card image cap">
  <div class="card-body">
 

<form action="" method="POST">
	<h3 class="text-success"> <?php echo $sucmsg ?> </h3>
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="taxt" class="form-control <?php 
if($ename !=""){
  echo "border-danger";
}



     ?>" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
    <small id="emailHelp" class="form-text text-danger"><?php echo $ename ?></small>
  </div>


  
<div class="form-group">
    <label for="exampleInputEmail1">Designation</label>
    <input type="text" class="form-control <?php 
if($edesignation!=""){
  echo "border-danger";
}



     ?>" name="designation" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Designation">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $edesignation ?></small>
  </div>
  



  

<div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control <?php 
if($eemail !=""){
  echo "border-danger";
}



     ?>" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Email">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $eemail?></small>
  </div>

         

  



  









<div class="form-group">
    <label for="exampleInputEmail1">Password</label>
    <input type="password" class="form-control <?php 
if($epassword!=""){
  echo "border-danger";
}



     ?>" name="password" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="password">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $epassword?></small>
  </div>

  <input type="submit" name="submit" class="btn btn-primary mt-5 offset-md-3" value="Submit ">
  
</form>








</div>


<?php include('footer.php') ?>