<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: admin-login.php');
}
?>




<?php

$result=mysqli_query($connection,"SELECT * FROM teacher");

?>



<div class="tbl offset-md-3">
<a class="btn btn-primary mt-5" href="add-teacher.php" role="button">Add Teacher</a>

<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Designation</th>
      <th scope="col">Email</th>
      
      
      
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($row=mysqli_fetch_array($result)){

?>

   <tr>
      <th scope="row">  <?php  echo  $key++ ?>   </th>
      <td> <?php  echo  $row['name'] ?></td>
      <td> <?php  echo  $row['designation'] ?></td>
      <td> <?php  echo  $row['email'] ?></td>
      
      
      <td>
      
      <a href="teacher_edit.php?id=<?php echo  $row['id'] ?>">Edit</a> |
      <a onclick="return confirm('are you sure to delete this ?')"  href="teacher_delete.php?id=<?php  echo  $row['id'] ?>">Delete</a>
      </td>
    </tr>
<?php 

}


}


?>

</tbody>
</table>

</div>













  <?php include('footer.php') ?>













  