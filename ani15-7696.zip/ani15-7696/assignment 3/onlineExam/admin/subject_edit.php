<?php include('header.php') ?>
<?php include('db.php') ?>


<?php
if(!isset($_SESSION['valid'])) {
  header('Location: admin-login.php');
}
?>







  
    
  

  <?php 

   
    $id=$_GET['id'];

    $result = mysqli_query($connection,"SELECT * FROM subject WHERE id=$id");

    if ($row=mysqli_fetch_array($result)) {

    ?>  

<?php 
 $name=$code=$email=$sucmsg="";


if (isset($_POST['submit'])){
 $id=$_POST['id'];
 $name=$_POST['name'];
$code=$_POST['code'];



 
 

 mysqli_query($connection,"UPDATE subject SET  name='$name', code='$code' WHERE id=$id");
 $sucmsg="Data Update Succesfully!";

}



?>





  <div class="col-md-4 offset-md-4 ">
  <div class="card ">
  <div class="card-body mt-4">
    <h3 class="text-success"> <?php echo $sucmsg ?> </h3>
  <form action="" method="POST" >

  <h3>Edit Subject</h3>
  <div class="form-group">
    <label for="exampleInputEmail1">Course Name</label>
    <input type="text" class="form-control"  value="<?php echo $row['name'] ?>" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Course name">
   
  </div>

<div class="form-group">
    <label for="exampleInputEmail1">Course Code</label>
    <input type="text" class="form-control"  value="<?php echo $row['code'] ?>" name="code" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Course Code">
    
  </div>





 



 









      
 



  <br>


  <input type="text"  name="id" hidden  value="<?php echo $row['id'] ?>">
<input type="submit"  name="submit" class="btn btn-primary" value="Update" >
<a class="btn btn-primary " href="subject.php" role="button">Back</a>
</form>


     
<?php

    }
   ?>


  </div>
  </div>

  </div> 


<?php include('footer.php')  ?>