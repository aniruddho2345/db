
<?php include('db.php') ?>

<?php  

  $id = $_GET['id'];   

echo $id;


mysqli_query($connection,"DELETE FROM  teacher WHERE id=$id");

$_SESSION['delmsg']="Delete Succesfully !";






header("Location:teacher.php");

 ?>


