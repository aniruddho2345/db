<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: admin-login.php');
}
?>







<?php

$result=mysqli_query($connection,"SELECT * FROM subject");

?>



<div class="tbl offset-md-3">
<a class="btn btn-primary mt-5" href="add_subject.php" role="button">Add Subject</a>

<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      <th scope="col">Id</th>
      <th scope="col">CourseName</th>
      <th scope="col">CourseCode</th>
      
      
      
      
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($row=mysqli_fetch_array($result)){

?>

   <tr>
      <th scope="row">  <?php  echo  $key++ ?>   </th>
      <td> <?php  echo  $row['name'] ?></td>
      <td> <?php  echo  $row['code'] ?></td>
      
      
      
      <td>
      
       <a href="subject_edit.php?id=<?php echo  $row['id'] ?>">Edit</a> |
      <a onclick="return confirm('are you sure to delete this ?')"  href="subject_delete.php?id=<?php  echo  $row['id'] ?>">Delete</a>
      </td>
    </tr>
<?php 

}


}


?>

</tbody>
</table>

</div>
