<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="img/5.png" type="image/gif">
	<meta charset="UTF-8">
	<title>Online Exam</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body class="body">

<nav class="navbar navbar-expand-lg navbar-light bg-light shadow">
	<img src="img/lo.jpg" style="height: 50px; width: 50px; margin-left: 500px;" alt="">
  <a class="navbar-brand" style="margin-left: 20px;" >Online Examination</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active justified nav " style="margin-left: 200px;">
        <a class="nav-link" href="#"  >Home <span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item dropdown content">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          login
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="student/student-login.php">Student</a>
          <a class="dropdown-item" href="teachers/teacher-login.php">Tecahers</a>
          
      </li>
      
    </ul>
    
  </div>
</nav> 

<div class="col-md-12">           

<div class="row">
	<div class="col-md-2"></div>
<div class="col-md-8">
	



<div class="bd-example mt-5">
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" data-interval="100">
      <div class="carousel-item active " >
        <img src="img/1.jpg" class="d-block w-100" style="height: 450px;" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5 style="color: rgb(90%, 90%, 4%)">Online Examination</h5>
          <p style="color: rgb(90%, 90%, 4%)">Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
      </div>
      <div class="carousel-item ">
        <img src="img/2.jpg" class="d-block w-100 " style="height: 450px;" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5 style="color: rgb(90%, 90%, 4%)">Online Examination</h5>
          <p style="color: rgb(90%, 90%, 4%)">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="img/3.jpg" class="d-block w-100"  style="height: 450px;" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5 style="color: rgb(90%, 90%, 4%)">Online Examination</h5>
          <p style="color: rgb(90%, 90%, 4%)">Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>











</div>
<div class="col-md-2"></div>
</div>




</div>
























<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	
</body>
</html>