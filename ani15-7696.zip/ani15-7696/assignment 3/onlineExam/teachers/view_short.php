<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>






<?php





$sid= $_GET['sid'];

$result=mysqli_query($connection,"SELECT * FROM short where subid=$sid ");

?>



<div class="tbl">


<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      
      <th scope="col">Question</th>
      
      <th scope="col">Corect</th>
      
      
      
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($row=mysqli_fetch_array($result)){

?>

   <tr>
      
      <td> <?php  echo  $row['short_question'] ?></td>
      <td> <?php  echo  $row['answer'] ?></td>
      
      
      
      
      <td>
      
       <a  href="short_question_edit.php?id=<?php  echo  $row['id'] ?>&sid=<?php  echo  $sid ?> " style="color: blue;">Edit</a><br> 
  <a   href="short_question_delete.php?id=<?php  echo  $row['id'] ?>&sid=<?php  echo  $sid ?> " style="color: blue;">Delete</a>
      </td>
    </tr>
<?php 

}


}


?>

</tbody>
</table>

</div>













  <?php include('footer.php') ?>













  