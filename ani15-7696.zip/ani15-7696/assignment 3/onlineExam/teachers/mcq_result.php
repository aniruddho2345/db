<?php include('header.php') ?>
<?php include('db.php') ?>


<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>






<?php

$result=mysqli_query($connection,"SELECT DISTINCT uid,subid FROM mcq_result");

?>



<div class="tbl offset-md-3">


<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      
      <th scope="col">Code</th>
      <th scope="col">Name</th>
      <th scope="col"> Correct Answer      </th>
      <th scope="col"> Wrong Answer     </th>
      <th scope="col"> Mark   </th>
      
      
      
     
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($checkuser=mysqli_fetch_array($result)){


$result1 = mysqli_query($connection,"SELECT subject.code,student.name,sum(mcq_result.correct) as correct,sum(mcq_result.wrong) as wrong,sum(mcq_result.mark) as mark FROM mcq_result INNER JOIN student ON mcq_result.uid=student.id INNER JOIN subject ON mcq_result.subid=subject.id  where mcq_result.uid='".$checkuser['uid']."' and mcq_result.subid='".$checkuser['subid']."'");

while($row=mysqli_fetch_array($result1)){


?>

<tr>	

<td><?php 	echo $row['code'] ?>	</td>
<td><?php 	echo $row['name'] ?>	</td>
<td> <?php 	echo $row['correct'] ?></td>
<td> <?php 	echo $row['wrong'] ?></td>
<td> <?php 	echo $row['mark'] ?></td>


</tr>







    
<?php 


}

}


}


?>

</tbody>
</table>

</div>


































<?php include('footer.php')  ?>



















