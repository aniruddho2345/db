
<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>




<?php 

   $sid=$_GET['sid'];


  $id = $_GET['id'];   

    

    $result = mysqli_query($connection,"SELECT * FROM short WHERE id=$id");

    if ($row=mysqli_fetch_array($result)) {

    ?>  



     

<?php 
 $short_question=$answer=$sucmsg="";


if (isset($_POST['submit'])){
 
 $short_question=$_POST['short_question'];
$answer=$_POST['answer'];

 

 mysqli_query($connection,"UPDATE short SET  short_question='$short_question', answer='$answer' WHERE id=$id");
 $sucmsg="Data Update Succesfully!";

}



?>



<div class="card text-center ">
  <div class="card-header shadow">
  Short Question
  </div>
  <div class="card-body">
    <h5 class="card-title">
        
<form action="" method="post">
<h3 class="text-success"> <?php echo $sucmsg ?> </h3>

<div class="form-group">
    <label for="exampleFormControlTextarea1">Question</label>
    <input type="text"  class="form-control" value="<?php echo $row['short_question'] ?>" name="short_question" id="exampleFormControlTextarea1" rows="3">
    
  </div>


 
  
    

  <div class="form-group">
    <label for="exampleFormControlInput1">Answer</label>
    <input type="text" class="form-control" value="<?php echo $row['answer'] ?>" name="answer" id="exampleFormControlInput1" placeholder="Correct Answer">
  </div>



<br>

 <input type="submit" name="submit" value="Update" class="btnn btn-primary">



</form>

<?php

    }
   ?>



    
</div>



<?php include('footer.php') ?>




