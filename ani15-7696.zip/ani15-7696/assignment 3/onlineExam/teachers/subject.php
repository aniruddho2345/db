	

<?php include('header.php') ?>
  
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>




<div>


<?php 


 $ename=$ecode=$sucmsg="";

if (isset($_POST['submit'])) {
  




if(empty($_POST['name'])){
  $ename="Name field must be required !";
  $name="";
}else{
  $name=$_POST['name'];
}
if(empty($_POST['code'])){
  $ecode="Code field must be required !";
  $code="";
}else{
  $code=$_POST['code'];
}




























if ($name !="" && $code !=""  ) {
 
 mysqli_query($connection,"INSERT INTO subject(name,code)VALUES('$name','$code')");

 $sucmsg="Add Succesfully!";

}


  


}


 ?>








<div class="card" style="width: 23rem; margin-left: 100px;" >
  
  <div class="card-body">
 

<form action="" method="POST">
	<h3 class="text-success"> <?php echo $sucmsg ?> </h3>
  <div class="form-group">
    <label for="exampleInputEmail1">Course Name</label>
    <input type="taxt" class="form-control <?php 
if($ename !=""){
  echo "border-danger";
}



     ?>" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Course Name">
    <small id="emailHelp" class="form-text text-danger"><?php echo $ename ?></small>
  </div>


  
<div class="form-group">
    <label for="exampleInputEmail1">Course Code</label>
    <input type="text" class="form-control <?php 
if($ecode !=""){
  echo "border-danger";
}



     ?>" name="code" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Course Code">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $ecode ?></small>
  </div>
  



  





  











  <input type="submit" name="submit" class="btn btn-primary mt-5 offset-md-3" value="Submit ">
  
</form>








</div>
</div>

<?php include('footer.php') ?>