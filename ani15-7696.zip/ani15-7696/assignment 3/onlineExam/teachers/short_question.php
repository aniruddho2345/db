
<?php include('header.php') ?>

<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>







<?php

$result=mysqli_query($connection,"SELECT * FROM subject");

?>



<div class="tbl offset-md-3">


<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      <th scope="col">Id</th>
      <th scope="col">CourseName</th>
      <th scope="col">CourseCode</th>
      
      
      
      
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($row=mysqli_fetch_array($result)){

?>

   <tr>
      <th scope="row">  <?php  echo  $key++ ?>   </th>
      <td> <?php  echo  $row['name'] ?></td>
      <td> <?php  echo  $row['code'] ?></td>
      
      
      
      <td>
      
      <a  href="add_short_question.php?sid=<?php echo  $row['id'] ?>" style="color: blue;">Add</a><br>   
      <a  href="view_short.php?sid=<?php  echo  $row['id'] ?> 

  " style="color: blue;">View List</a> 
      </td>
    </tr>
<?php 

}


}


?>

</tbody>
</table>

</div>





























<?php include('footer.php') ?>




















