<?php include('header.php') ?>


<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>




























  <?php include('footer.php') ?>
    

    















