<?php include('header.php') ?>

<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>







<?php 

$field_name="opt".rand(1,100);
 $equestion=$eanswer1=$eanswer2=$eanswer3=$eanswer4=$ecorrect_answer=$sucmsg="";
 

if (isset($_POST['submit'])) {
  




if(empty($_POST['question'])){
  $equestion="Name field must be required !";
  $question="";
}else{
  $question=$_POST['question'];
}
if(empty($_POST['answer1'])){
  $eanswer1="answer1 field must be required !";
  $answer1="";
}else{
  $answer1=$_POST['answer1'];
}

if(empty($_POST['answer2'])){
  $eanswer2="answer2 field must be required !";
  $answer2="";
}else{
  $answer2=$_POST['answer2'];
}

if(empty($_POST['answer3'])){
  $eanswer3="answer3 field must be required !";
  $answer3="";
}else{
  $answer3=$_POST['answer3'];
}

if(empty($_POST['answer4'])){
  $eanswer4="answer4 field must be required !";
  $answer4="";
}else{
  $answer4=$_POST['answer4'];
}

if(empty($_POST['correct_answer'])){
  $ecorrect_answer="correct_answer field must be required !";
  $correct_answer="";
}else{
  $correct_answer=$_POST['correct_answer'];
}


if ($question !="" && $answer1 !="" && $answer2 !="" && $answer3 !="" && $answer4 !="" && $correct_answer !=""   ) {



mysqli_query($connection,"insert into mcq(subid,tid,question,answer1,answer2,answer3,answer4,correct_answer,field_name)values('".$_GET['sid']."','".$_SESSION['id']."','".$_POST['question']."','".$_POST['answer1']."','".$_POST['answer2']."','".$_POST['answer3']."','".$_POST['answer4']."','".$_POST['correct_answer']."','".$field_name."')");



 $sucmsg="Add Succesfully!";
}
}

 ?>



<div class="card text-center">
  <div class="card-header shadow">
    MCQ
  </div>
  <div class="card-body">
    <h5 class="card-title">
        
<form action="" method="post">
<h3 class="text-success"> <?php echo $sucmsg ?> </h3>

<div class="form-group">
    <label for="exampleFormControlTextarea1">Question</label>
    <textarea class="form-control


<?php 
if($equestion !=""){
  echo "border-danger";
}



     ?>




    


    " name="question" id="exampleFormControlTextarea1" rows="3"></textarea>
    <small id="emailHelp" class="form-text text-danger"><?php echo $equestion ?></small>
  </div>


 <div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">1</label>
    <input type="text" class="form-control col-md-5

<?php 
if($eanswer1 !=""){
  echo "border-danger";
}



     ?>








    

    " name="answer1" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
    <small id="emailHelp" class="form-text text-danger"><?php echo $eanswer1 ?></small>
    
  </div>
<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">2</label>
    <input type="text" class="form-control col-md-5 



<?php 
if($eanswer2 !=""){
  echo "border-danger";
}



     ?>







    " name="answer2" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
    <small id="emailHelp" class="form-text text-danger"><?php echo $eanswer2 ?></small>
    
  </div>



<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">3</label>
    <input type="text" class="form-control col-md-5
<?php 
if($eanswer3 !=""){
  echo "border-danger";
}



     ?>







    " name="answer3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
    <small id="emailHelp" class="form-text text-danger"><?php echo $eanswer3 ?></small>
  </div>

<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">4</label>
    <input type="text" class="form-control col-md-5


<?php 
if($eanswer4 !=""){
  echo "border-danger";
}



     ?>




    " name="answer4"  id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
    <small id="emailHelp" class="form-text text-danger"><?php echo $eanswer4 ?></small>
    
  </div>

<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">#</label>
    <input type="text" class="form-control col-md-5


<?php 
if($ecorrect_answer !=""){
  echo "border-danger";
}



     ?>




    " name="correct_answer" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Correct Answer">
    <small id="emailHelp" class="form-text text-danger"><?php echo $ecorrect_answer ?></small>
    
  </div>
<br>

 <input type="submit" name="submit" value="Add" class="btnn btn-primary">



</form>




    
</div>




















<?php include('footer.php') ?>