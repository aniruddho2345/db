<?php include('db.php') ?>

<?php  


$sid=$_GET['sid'];


  $id = $_GET['id'];   

echo $id;


mysqli_query($connection,"DELETE FROM  short WHERE id=$id");

$_SESSION['delmsg']="Delete Succesfully !";




header('Location:view_short.php?sid='.$sid);


 ?>

