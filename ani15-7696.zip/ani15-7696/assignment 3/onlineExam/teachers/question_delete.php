
<?php include('db.php') ?>

<?php  


$sid=$_GET['sid'];


  $mcqid = $_GET['mcqid'];   

echo $mcqid;


mysqli_query($connection,"DELETE FROM  mcq WHERE mcqid=$mcqid");

$_SESSION['delmsg']="Delete Succesfully !";




header('Location:view_mcq.php?sid='.$sid);


 ?>

