<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>







  <div class="col-md-6  details bg-light    ">
  <div class="card bg-light text-dark ">
  <div class="card-body mt-4 bg-light text-dark  ">










  <?php 

    $uid= $_SESSION['id'];

    $result = mysqli_query($connection,"SELECT * FROM teacher WHERE id=$uid");

    if ($row=mysqli_fetch_array($result)) {

    ?>  
      
  <span>Name : <?php echo $row['name'] ?>   </span><br>
  <br>
<span>Designation: <?php echo $row['designation'] ?> </span><br>
<br>

<br>
<span>email : <?php echo $row['email'] ?> </span><br>

 
  
  <a class="btn btn-primary mt-4 offset-md-1" href="update.php" role="button">Update</a>


     
<?php

    }
   ?>

 

  

  </div>
  </div>
  


  </div> 
















<?php include('footer.php') ?>