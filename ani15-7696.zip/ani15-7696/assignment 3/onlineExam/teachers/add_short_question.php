
<?php include('header.php') ?>
<?php include('db.php') ?>


<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>















<?php 



 $eshort_question=$eanswer=$sucmsg="";
 

if (isset($_POST['submit'])) {
  




if(empty($_POST['short_question'])){
  $equestion="Name field must be required !";
  $short_question="";
}else{
  $short_question=$_POST['short_question'];
}
if(empty($_POST['answer'])){
  $eanswer1="answer field must be required !";
  $answer="";
}else{
  $answer=$_POST['answer'];
}






if ($short_question !="" && $answer !=""  ) {



mysqli_query($connection,"insert into short (subid,tid,short_question,answer)values('".$_GET['sid']."','".$_SESSION['id']."','".$_POST['short_question']."','".$_POST['answer']."')");



 $sucmsg="Add Succesfully!";
}
}

 ?>






















<div class="card text-center">
  <div class="card-header shadow">
   Short Question
  </div>
  <div class="card-body">
    <h5 class="card-title">
<form action="" method="post">
<h3 class="text-success"> <?php echo $sucmsg ?> </h3>

<div class="form-group">
    <label for="exampleFormControlTextarea1">Question</label>
    <textarea class="form-control" name="short_question" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>




  <div class="form-group">
    <label for="exampleFormControlInput1">Answer</label>
    <input type="text" class="form-control" name="answer" id="exampleFormControlInput1" placeholder="Correct Answer">
  </div>


<input type="submit" name="submit" value="Add" class="btnn btn-primary">


</form>

















<?php include('footer.php') ?>
