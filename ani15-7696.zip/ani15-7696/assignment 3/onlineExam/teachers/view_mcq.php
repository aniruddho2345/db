<?php include('header.php') ?>
<?php include('db.php') ?>


<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>





<?php





$sid= $_GET['sid'];

$result=mysqli_query($connection,"SELECT * FROM mcq where subid=$sid ");

?>



<div class="tbl">


<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      
      <th scope="col">Question</th>
      <th scope="col">Answer1</th>
      <th scope="col">Answer2</th>
      <th scope="col">Answer3</th>
      <th scope="col">Answer4</th>
      <th scope="col">Corect</th>
      
      
      
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($row=mysqli_fetch_array($result)){

?>

   <tr>
      
      <td> <?php  echo  $row['question'] ?></td>
      <td> <?php  echo  $row['answer1'] ?></td>
      <td> <?php  echo  $row['answer2'] ?></td>
      <td> <?php  echo  $row['answer3'] ?></td>
      <td> <?php  echo  $row['answer4'] ?></td>
      <td> <?php  echo  $row['correct_answer'] ?></td>
      
      
      
      <td>
      
      <a  href="question_edit.php?mcqid=<?php  echo  $row['mcqid'] ?>&sid=<?php  echo  $sid ?> " style="color: blue;">Edit</a> 
  <a   href="question_delete.php?mcqid=<?php  echo  $row['mcqid'] ?>&sid=<?php  echo  $sid ?> " style="color: blue;">Delete</a>
      </td>
    </tr>
<?php 

}


}


?>

</tbody>
</table>

</div>













  <?php include('footer.php') ?>













  