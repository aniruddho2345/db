<?php 


echo $_POST['question'].'<br>';
echo $_POST['answer1'].'<br>';
echo $_POST['answer2'].'<br>';
echo $_POST['answer3'].'<br>';
echo $_POST['answer4'].'<br>';
echo $_POST['correct_answer'].'<br>';

 $sid=$_GET['sid'];

echo  $sid;

 ?>