<?php include('header.php') ?>
<?php include('db.php') ?>


<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>









<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      
     
      <th scope="col"> CODE     </th>
      <th scope="col"> Name     </th>
      <th scope="col"> Mark   </th>
      
      
      
     
    </tr>
  </thead>
  <tbody>
  <?php 
 
$uid=$_SESSION['id'];


$result1 = mysqli_query($connection,"SELECT student.name,subject.code,short_result.mark FROM short_result  INNER JOIN subject ON short_result.subid=subject.id INNER JOIN student ON student.id=short_result.uid" );

while($row=mysqli_fetch_array($result1)){


?>

<tr>  

<td> <?php  echo $row['code'] ?></td>
<td> <?php  echo $row['name'] ?></td>
<td> <?php  echo $row['mark'] ?></td>


</tr>







    
<?php 


}




?>

</tbody>
</table>

</div>


<?php include('footer.php')  ?>






















