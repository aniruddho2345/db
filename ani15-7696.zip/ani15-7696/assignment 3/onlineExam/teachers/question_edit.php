
<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>





<?php 

   $sid=$_GET['sid'];


  $mcqid = $_GET['mcqid'];   

    

    $result = mysqli_query($connection,"SELECT * FROM mcq WHERE mcqid=$mcqid");

    if ($row=mysqli_fetch_array($result)) {

    ?>  



     

<?php 
 $question=$answer1=$answer2=$answer3=$answer4=$correct_answer=$sucmsg="";


if (isset($_POST['submit'])){
 
 $question=$_POST['question'];
$answer1=$_POST['answer1'];
$answer2=$_POST['answer2'];
$answer3=$_POST['answer3'];
$answer4=$_POST['answer4'];
$correct_answer=$_POST['correct_answer'];
 
 

 mysqli_query($connection,"UPDATE mcq SET  question='$question', answer1='$answer1',answer2='$answer2',
 answer3='$answer3',answer4='$answer4',correct_answer='$correct_answer' WHERE mcqid=$mcqid");
 $sucmsg="Data Update Succesfully!";

}



?>



<div class="card text-center">
  <div class="card-header">
    MCQ
  </div>
  <div class="card-body">
    <h5 class="card-title">
        
<form action="" method="post">
<h3 class="text-success"> <?php echo $sucmsg ?> </h3>

<div class="form-group">
    <label for="exampleFormControlTextarea1">Question</label>
    <input type="text"  class="form-control" value="<?php echo $row['question'] ?>" name="question" id="exampleFormControlTextarea1" rows="3">
    
  </div>


 <div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">1</label>
    <input type="text" class="form-control col-md-5" value="<?php echo $row['answer1'] ?>" name="answer1" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
  
    
  </div>
<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">2</label>
    <input type="text" class="form-control col-md-5" value="<?php echo $row['answer2'] ?>" name="answer2" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
    
    
  </div>



<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">3</label>
    <input type="text" class="form-control col-md-5" value="<?php echo $row['answer3'] ?>" name="answer3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
    
  </div>

<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">4</label>
    <input type="text" class="form-control col-md-5" value="<?php echo $row['answer4'] ?>" name="answer4"  id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Option">
  
    
  </div>

<div class="form-group row">
    <label for="staticEmail" class="col-sm-1 col-form-label">#</label>
    <input type="text" class="form-control col-md-5" value="<?php echo $row['correct_answer'] ?>" name="correct_answer" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Correct Answer">
    
    
  </div>
<br>

 <input type="submit" name="submit" value="Update" class="btnn btn-primary">



</form>

<?php

    }
   ?>



    
</div>



<?php include('footer.php') ?>




