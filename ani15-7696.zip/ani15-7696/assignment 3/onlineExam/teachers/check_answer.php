<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>





<?php

$result=mysqli_query($connection,"SELECT DISTINCT(uid) as uid,subid FROM short_exam");

?>



<div class="tbl offset-md-3">


<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      
      <th scope="col">Code</th>
      <th scope="col">Name</th>
     
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($checkuser=mysqli_fetch_array($result)){


$result1=mysqli_query($connection,"SELECT * FROM student where id='".$checkuser['uid']."' ");
while($row=mysqli_fetch_array($result1)){


$sub=mysqli_query($connection,"SELECT * FROM subject where id='".$checkuser['subid']."' ");
while ( $row1=mysqli_fetch_array($sub)) {
	


?>



<tr>	
<td><?php 	echo $row1['code'] ?></td>
<td><?php 	echo $row['name'] ?>	</td>
<td> <a href="answersheet.php?uid=<?php 	echo $row['id'] ?>&sid=<?php echo $checkuser['subid'] ?>">Check Answer</a>	</td>

</tr>







    
<?php 
}

}

}


}


?>

</tbody>
</table>

</div>


































<?php include('footer.php')  ?>