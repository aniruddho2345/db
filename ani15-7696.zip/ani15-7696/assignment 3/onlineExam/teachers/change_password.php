<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>






<?php

    


 
if (isset($_POST['re_password']))
  {
   
  $old_pass = md5($_POST['old_pass']);
  $new_pass = md5($_POST['new_pass']);
  $re_pass = md5($_POST['re_pass']);


$uid= $_SESSION['id'];
  $password_query = mysqli_query($connection,"SELECT * FROM teacher WHERE id=$uid");
  $password_row = mysqli_fetch_array($password_query);
  $database_password = $password_row['password'];
  if ($database_password == $old_pass)
    {
    if ($new_pass == $re_pass)
      {
      $update_pwd = mysqli_query($connection,"UPDATE  teacher set password='$new_pass' WHERE id=$uid");
      echo "<script>alert('Update Sucessfully'); window.location='change_password.php'</script>";
      }
      else
      {
      echo "<script>alert('Your new and Retype Password is not match'); window.location='change_password.php'</script>";
      }
    }
    else
    {
    echo "<script>alert('Your old password is wrong'); window.location='change_password.php'</script>";
    }
   }
 
?>









<div class="card bg-light  text-center " style="max-width: 20rem;  text-align: center; margin-left: px; margin-top: ">
  <div class="card-header" style="font-size: 25px; font-family: Century Gothic;"><b>Change Password </b></div>
  <div class="card-body">
    <form method="post" action="">
  <div class="form-group">
    <div class="textbox">
    
    <input type="password" name="old_pass" placeholder="Old Password . . . . .">
  </div>
    
  </div>



  <div class="form-group">
      <div class="textbox">
    
    <input type="password" name="new_pass" placeholder="New Password . . . . .">
  </div>
  </div>




<div class="form-group">
<div class="textbox">
    
     <input type="password" name="re_pass" placeholder="Re-Type New Password . . . . .">
  </div>

</div>




  
 <button type="submit" name="re_password" class="btnn btn-primary">Change</button>

  
</form>
  </div>
</div>











  


























<?php include('footer.php') ?>