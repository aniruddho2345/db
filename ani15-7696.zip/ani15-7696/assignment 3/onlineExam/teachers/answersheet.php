<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: teacher-login.php');
}
?>








<?php 

    $uid= $_GET['uid'];

    $result = mysqli_query($connection,"SELECT short_exam.answer,short.short_question  FROM short_exam INNER JOIN short ON short_exam.qid=short.id WHERE short_exam.uid=$uid" );

    while ($row=mysqli_fetch_assoc($result)) {







    ?>  

<?php 	echo  'q: '.  $row['short_question'].'<br>'?>
<?php 	echo 'a: '.$row['answer'].'<br>'?> 

<?php }	 ?>











<?php 


 $emark=$sucmsg="";

if (isset($_POST['submit'])) {
  
$uid=$_GET['uid'];
$sid=$_GET['sid'];



if(empty($_POST['mark'])){
  
}else{
  $mark=$_POST['mark'];
}

if ($mark !=""   ) {
 
 mysqli_query($connection,"INSERT INTO short_result(uid,subid,mark)VALUES('$uid','$sid','$mark')");

 $sucmsg="Marked Succesfully!";

}


  


}


 ?>










<form action="" method="POST">
  
  <div class="form-group row">
    
    <div class="col-sm-2">
      <input type="text" class="form-control" id="inputEmail3" name="mark" placeholder="Mark">
    </div>

<input type="submit" name="submit" class="btn btn-primary">

<h3 class="text-success"> <?php echo $sucmsg ?> </h3>
   </from>









<?php include('footer.php')  ?>