
<?php include('header.php') ?>
  
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: student-login.php');
}
?>





<?php 

$sid=$_GET['sid'];
$qid=$_GET['qid'];
$uid = $_SESSION['id'];
 $eanswer=$sucmsg="";

if (isset($_POST['submit'])) {
  




if(empty($_POST['answer'])){
  $eanswer="Answer field must be required !";
  $answer="";
}else{
  $answer=$_POST['answer'];
}























if ($answer !="" ) {
 
 mysqli_query($connection,"INSERT INTO short_exam(uid,subid,qid,answer)VALUES('$uid','$sid','$qid','$answer')");

 $sucmsg="Answer  Submitted!";

}


  


}


 ?>










<form action="" method="POST">
	<h3 class="text-success"> <?php echo $sucmsg ?> </h3>
	
 <div class="form-group">
    <label for="exampleFormControlTextarea1">Example textarea</label>
    <textarea class="form-control" name="answer" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>



<input type="submit" name="submit" value="Answer" class="btn btn-primary">





</form>































<?php include('footer.php') ?>