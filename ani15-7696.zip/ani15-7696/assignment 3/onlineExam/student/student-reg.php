<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="icon" href="img/5.png" type="image/gif">
	<meta charset="UTF-8">
	<title>StudentRegistration</title>

<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">



</head>
<body>
	
<?php include('db.php') ?>






<?php 


 $ename=$esid=$eemail=$epassword=$sucmsg="";

if (isset($_POST['submit'])) {
  




if(empty($_POST['name'])){
  $ename="Name field must be required !";
  $name="";
}else{
  $name=$_POST['name'];
}
if(empty($_POST['sid'])){
  $esid="Srudent id field must be required !";
  $sid="";
}else{
  $sid=$_POST['sid'];
}



if(empty($_POST['email'])){
  $eemail="email field must be required !";
  $email="";
}else{
  $email=$_POST['email'];
}























if(empty($_POST['password'])){
  $epassword="password field must be required !";
  $password="";
}else{
  $password=md5($_POST['password']);
}


if ($name !="" && $sid !=""  && $email !=""  && $password !="") {
 
 mysqli_query($connection,"INSERT INTO student(name,sid,email,password)VALUES('$name','$sid','$email','$password')");

 $sucmsg="Register Succesfully!";

}


  


}


 ?>


























<div class="card" style="width: 23rem; margin-left: 470px; " >
  <img class="card-img-top" src="img/re.jpg" alt="Card image cap">
  <div class="card-body">
 

<form action="" method="POST">
	<h3 class="text-success"> <?php echo $sucmsg ?> </h3>
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control <?php 
if($ename !=""){
  echo "border-danger";
}



     ?>" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
    <small id="emailHelp" class="form-text text-danger"><?php echo $ename ?></small>
  </div>


  
<div class="form-group">
    <label for="exampleInputEmail1">Student Id</label>
    <input type="text" class="form-control <?php 
if($esid !=""){
  echo "border-danger";
}



     ?>" name="sid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Student ID">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $esid ?></small>
  </div>
  



  

<div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control <?php 
if($eemail !=""){
  echo "border-danger";
}



     ?>" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Email">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $eemail?></small>
  </div>

         

  



  









<div class="form-group">
    <label for="exampleInputEmail1">Password</label>
    <input type="password" class="form-control <?php 
if($epassword!=""){
  echo "border-danger";
}



     ?>" name="password" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="password">
    <small id="emailHelp" class="form-text text-danger"> <?php echo $epassword?></small>
  </div>

  <input type="submit" name="submit" class="btn btn-primary mt-5 offset-md-3" value="Submit ">
  <a class="btn btn-primary mt-5 " href="student-login.php" role="button">Back</a>
  
</form>








</div>














<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>