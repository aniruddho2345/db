
    <?php include('header.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: student-login.php');
}
?>




























  <?php include('footer.php') ?>
    

    















