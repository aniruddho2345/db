<?php include('header.php')  ?>
<?php include('db.php') ?>
<?php
if(!isset($_SESSION['valid'])) {
  header('Location: student-login.php');
}
?>



  <?php 

   
    $uid= $_SESSION['id'];

    $result = mysqli_query($connection,"SELECT * FROM student WHERE id=$uid");

    if ($row=mysqli_fetch_array($result)) {

    ?>  

<?php 
 $name=$sid=$email=$password=$sucmsg="";


if (isset($_POST['submit'])){
 $id=$_POST['id'];
 $name=$_POST['name'];
$sid=$_POST['sid'];

$email=$_POST['email'];



 mysqli_query($connection,"UPDATE student SET  name='$name', sid='$sid',email='$email'  WHERE id=$id");
 $sucmsg="Data Update Succesfully!";

}



?>






  <div class="col-md-8 ">
  <div class="card ">
  <div class="card-body mt-4">
    <h3 class="text-success"> <?php echo $sucmsg ?> </h3>
  <form action="" method="POST" >

  <h3>Edit Info</h3>
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control"  value="<?php echo $row['name'] ?>" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter name">
   
  </div>

<div class="form-group">
    <label for="exampleInputEmail1">Student ID</label>
    <input type="text" class="form-control"  value="<?php echo $row['sid'] ?>" name="sid" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Student Id">
    
  </div>




  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" class="form-control"  value="<?php echo $row['email'] ?>" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    
  </div>


  


 











      
 



  <br>


  <input type="text"  name="id" hidden  value="<?php echo $row['id'] ?>">
<input type="submit"  name="submit" class="btn btn-primary" value="Update" >
 <a class="btn btn-primary " href="student_dashboard.php" role="button">Back</a>

</form>


     
<?php

    }
   ?>


  </div>
  </div>

  </div> 








































<?php include('footer.php') ?>

