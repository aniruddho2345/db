
<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: student-login.php');
}
?>




<?php

$sid=$_GET['sid'];

$result=mysqli_query($connection,"SELECT * FROM short where subid=$sid");

?>



<div class="tbl offset-md-3">


<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      <th scope="col">Id</th>
      <th scope="col">Question</th>
      
      
      
      
      
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php 
 
if (mysqli_num_rows($result) > 0){
 $key=1;


while($row=mysqli_fetch_array($result)){

?>

   <tr>
      <th scope="row">  <?php  echo  $key++ ?>   </th>
      <td> <?php  echo  $row['short_question'] ?></td>
      
      
      
      
      <td>
      
      <a  href="examsheet.php?sid=<?php echo $sid?>&qid=<?php  echo  $row['id'] ?>

  " style="color: blue;">Give Answer</a> 
      
      </td>
    </tr>
<?php 

}


}


?>

</tbody>
</table>

</div>





























<?php include('footer.php') ?>




















