<?php include('header.php') ?>
<?php include('db.php') ?>

<?php
if(!isset($_SESSION['valid'])) {
  header('Location: student-login.php');
}
?>


<?php
$sid=$_GET['sid'];

 if (isset($_POST['submit'])) {

      $uid=$_SESSION['id'];
		$mcqid=$_POST['mcqid'];
		$checkmcq=mysqli_query($connection,"SELECT * FROM mcq where mcqid=$mcqid");

		$result=mysqli_fetch_array($checkmcq);
		if ($result['correct_answer']==$_POST['question']) {
			$mark=1;
			$correct=1;
			$wrong=0;

		}else{
			$mark=0;
			$wrong=1;
			$correct=0;
		}

     mysqli_query($connection,"INSERT INTO mcq_result (uid,subid,correct,wrong,mark)VALUES('".$uid."','".$_GET['sid']."','".$correct."','".$wrong."','".$mark."')");


if($_POST['pageno'] == $_POST['total']){
		
}else{
	echo "success";
}

  $pageno = $_POST['pageno'];

        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 1;
        $offset = ($pageno-1) * $no_of_records_per_page;

    
        $total_pages_sql = "SELECT COUNT(*) FROM mcq WHERE subid= $sid";
        $result = mysqli_query($connection,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);

        $sql = "SELECT * FROM mcq WHERE subid= $sid  LIMIT $offset, $no_of_records_per_page";
        $res_data = mysqli_query($connection,$sql);
        if($row = mysqli_fetch_array($res_data)){


?>

<form action="" method="post" id="qform">

<span>Question : <?php echo $row['question'] ?>   </span><br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="question" id="exampleRadios1" value="<?php echo $row['answer1']   ?>" >

  <label class="form-check-label" for="exampleRadios1">
    <?php echo $row['answer1'] ?>
  </label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="question" id="exampleRadios2" value="<?php echo $row['answer2']   ?>">
  <label class="form-check-label" for="exampleRadios2">
     <?php echo $row['answer2'] ?>
  </label>
</div>


<div class="form-check">
  <input class="form-check-input" type="radio" name="question"id="exampleRadios2" value="<?php echo $row['answer3']   ?>">
  <label class="form-check-label" for="exampleRadios2">
     <?php echo $row['answer3'] ?>
  </label>
</div>


<div class="form-check">
  <input class="form-check-input" type="radio" name="question" id="exampleRadios2" value="<?php echo $row['answer4']   ?>">
  <label class="form-check-label" for="exampleRadios2">
     <?php echo $row['answer4'] ?>
  </label>
</div>

<input type="hidden" name="pageno" value="<?php echo $pageno + 1?>">
 <input type="submit" class="button" name="submit" value="Next">
 <input type="hidden"name="mcqid" value="<?php echo $row['mcqid'] ?>">
 <input type="hidden"name="total" value="<?php echo $total_pages ?>">

  </form>


<?php  


        }
         





    ?>




<!-- 

<a onclick="document.getElementById('qform').submit()" class="btn btn-primary" href="http://localhost/onlineExam/student/exam_mcq.php?sid=<?php echo $sid ?>&pageno=<?php echo $pageno + 1 ?> ">Next</a>

 -->







<?php include('footer.php') ?>