<?php session_start() ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link rel="icon" href="img/5.png" type="image/gif">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">

    <title>OnlineExamination</title>
  </head>
  <body>
   

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#" style="margin-left: 550px;">Online Examination</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  
</nav>








<div class="col-md-12">
  
<div class="row">
  
<div class="col-md-3"> 


   
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>Student</h3>
        </div>
        
        
        <ul class="list-unstyled components">
           
            <li class="active">
                <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
                <ul class="collapse list-unstyled" id="homeSubmenu">
                    <li>
                        <a href="myprofile.php">Profile</a>
                    </li>
                    <li>
                        <a href="change_password.php">Change Password</a>
                    </li>
                    
                </ul> 
            </li>
            
            
            <li>
                <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Exam</a>
                <ul class="collapse list-unstyled" id="pageSubmenu">
                  
                    <li>
                        <a href="mcq.php">MCQ</a>
                    </li>
                    <li>
                        <a href="short_question.php">Short Question</a>
                    </li>
                </ul> 
            </li>
             <li class="active">
                <a href="#Submenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Result</a>
                <ul class="collapse list-unstyled" id="Submenu">
                    <li>
                        <a href="mcq_result.php">MCQ</a>
                    </li>
                    <li>
                        <a href="short_result.php">Short Question</a>
                    </li>
                    
                </ul> 
            </li>
            <li>
                <a href="logout.php">Log Out</a>
            </li>
        </ul>
        
        
    </nav>
    
    












</div>
<div class="col-md-6">
  

