<?php include('header.php') ?>
<?php include('db.php') ?>



<?php
if(!isset($_SESSION['valid'])) {
  header('Location: student-login.php');
}
?>






<table class="table text-dark">
  <thead>
    <tr>
      <tr>
      
     
      <th scope="col"> CODE     </th>
      <th scope="col"> Correct   </th>
      <th scope="col"> wrong  </th>
      <th scope="col"> Mark   </th>
      
      
      
     
    </tr>
  </thead>
  <tbody>
  <?php 
 


$uid=$_SESSION['id'];



$result=mysqli_query($connection,"SELECT DISTINCT uid,subid FROM mcq_result");




while($checkuser=mysqli_fetch_array($result)){

$result1 = mysqli_query($connection,"SELECT student.name,subject.code,sum(mcq_result.correct) as correct,sum(mcq_result.wrong) as wrong,sum(mcq_result.mark) as mark FROM mcq_result  INNER JOIN subject ON mcq_result.subid=subject.id INNER JOIN student ON student.id=mcq_result.uid where mcq_result.uid=$uid and mcq_result.subid='".$checkuser['subid']."'" );

while($row=mysqli_fetch_array($result1)){


?>

<tr>  

<td> <?php  echo $row['code'] ?></td>
<td> <?php  echo $row['correct'] ?></td>
<td> <?php  echo $row['wrong'] ?></td>
<td> <?php  echo $row['mark'] ?></td>


</tr>







    
<?php 


}



}



?>

</tbody>
</table>

</div>


<?php include('footer.php')  ?>












































<?php include('footer.php')  ?>